package jdbc_p;

import java.util.ArrayList;

public class StudList2 {

	/*Student [] st = new Student[5];

	public Student[] getSt() {
		return st;
	}

	public void setSt(Student[] st) {
		this.st = st;
	}*/
	
	
	ArrayList<Student>student = new ArrayList<>();

	public ArrayList<Student> getStudent() {
		return student;
	}

	public void setStudent(ArrayList<Student> student) {
		this.student = student;
	}

	

	
}
