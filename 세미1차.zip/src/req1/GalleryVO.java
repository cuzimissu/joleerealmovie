package req1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class GalleryVO {

	
	Integer num;
	String name, cate;
	public Integer getNum() {
		return num;
	}
	public void setNum(Integer num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCate() {
		return cate;
	}
	public void setCate(String cate) {
		this.cate = cate;
	}
	
	
	
	
}
